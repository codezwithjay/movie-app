const mongoose = require('mongoose');

const MovieSchema = new mongoose.Schema({
    title: String,
    description:String,
   
}, {
    timestamps: true
})

const MovieModel = mongoose.model('Movie', MovieSchema)

module.exports = MovieModel