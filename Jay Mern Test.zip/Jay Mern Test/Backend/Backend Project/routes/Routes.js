const express = require("express");
const {
  addMovie,
  showMovies,
  updateMovie,
  showMovie,
  deleteMovie,
} = require("../controllers/MovieController");

const routes = express.Router();

routes.post("/add", addMovie);
routes.get("/", showMovies);
routes.put("/:id", updateMovie);
routes.get("/movie/:id", showMovie);
routes.delete("/del/:id", deleteMovie);

module.exports = routes;
