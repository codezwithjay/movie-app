const { Model } = require("mongoose");
const MovieModel = require("../models/Model");

exports.addMovie = async (req, res) => {
  const new_Movie = new MovieModel(req.body);
  const result = await new_Movie.save();
  res.status(200).json(result);
};

exports.showMovies = async (req, res) => {
  const Movies = await MovieModel.find();
  if (Movies != null) {
    res.status(200).json(Movies);
  } else {
    res.status(404).json({ message: "No Movies" });
  }
};

exports.showMovie = async (req, res) => {
  const Movie = await MovieModel.findById(req.params.id);
  if (Movie != null) {
    res.status(200).json(Movie);
  } else {
    res.status(400).json({ message: "not Movie found" });
  }
};

exports.updateMovie = async (req, res) => {
  const result = await MovieModel.findByIdAndUpdate(req.params.id, req.body);
  res.status(200).json(result);
};

exports.deleteMovie = async (req, res) => {
  const result = await MovieModel.findByIdAndDelete(req.params.id);
  res.json(result);
};
