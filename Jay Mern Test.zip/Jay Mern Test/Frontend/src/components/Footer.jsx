import React from "react";

const Footer = () => {
  return (
    <footer className="bg-dark text-white text-center py-3">
      <div className="container">
        <small>All Rights Reserved &copy; MovieHeist 2025</small>
      </div>
    </footer>
  );
};

export default Footer;
