import { BrowserRouter, Route, Routes } from "react-router-dom";
import Navbar from "./components/Navbar";
import Home from "./components/Home";
import Footer from "./components/Footer";
import "bootstrap/dist/css/bootstrap.min.css";
import AddMovies from "./components/AddMovie";
import ShowMovie from "./components/ShowMovie";
import UpdateMovie from "./components/UpdateMovie";

function App() {
  return (
    <div className="d-flex flex-column min-vh-100">
      <BrowserRouter>
        <Navbar />
        
        {/* Main content with top padding and container for spacing */}
        <main className="flex-fill container pt-5 mt-3">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/add" element={<AddMovies />} />
            <Route path="/:id" element={<ShowMovie />} />
            <Route path="/update/:id" element={<UpdateMovie />} />
          </Routes>
        </main>

        <Footer />
      </BrowserRouter>
    </div>
  );
}

export default App;
